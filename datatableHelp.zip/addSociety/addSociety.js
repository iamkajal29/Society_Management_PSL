import { LightningElement } from 'lwc';

export default class AddSociety extends LightningElement {}