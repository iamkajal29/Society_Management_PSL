import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class AddNewSociety extends LightningElement {
    @api societyId;
    handleSuccess(event){
        this.societyId = event.detail.id
        //reset the fields to BLANK after successful save
        const inputFields = this.template.querySelectorAll(
            'lightning-input-field'
        );
        if (inputFields) {
            inputFields.forEach(field => {
                field.reset();
            });
        }
        //raise a toast to inform user about successful save
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Record Success',
                message: 'Society Successfully Created',
                variant: 'success'
            })
        );
            
    }
}