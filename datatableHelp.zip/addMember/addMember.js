import { LightningElement, wire, api } from 'lwc';
import getContactList from '@salesforce/apex/addMemberController.getContactList';
import { updateRecord } from 'lightning/uiRecordApi';
import SOCIETY_FIELD from '@salesforce/schema/Contact.Society__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ID_FIELD from '@salesforce/schema/Contact.Id';

const columns = [
    { label: 'Name', fieldName: 'Name' },
];
export default class AddMember extends LightningElement {

    error;
    columns = columns;
    @api societyId;
    @wire(getContactList)
    contacts;
    selectedIdsArray = [];
    
    addMemberModal = false;

    handleclick(){
        var selectedRows = this.template.querySelector('lightning-datatable').getSelectedRows();
        
        for (const element of selectedRows) {
            const fields = {};
            fields[ID_FIELD.fieldApiName] = element.Id;
            fields[SOCIETY_FIELD.fieldApiName] = this.societyId;

            const recordInput = { fields };

            updateRecord(recordInput)
                .then(() => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Contact updated',
                            variant: 'success'
                        })
                    );
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error creating record',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
        }
        this.closeModal();
    }


    handleAddMember(){
        this.addMemberModal = true;
    }
    closeModal(){
        this.addMemberModal = false;
    }
}